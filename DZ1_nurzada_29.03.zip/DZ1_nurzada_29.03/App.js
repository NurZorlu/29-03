var month = prompt("Enter your birth month").toLowerCase();
var day = Number(prompt("Enter your birth day"));

if (day < 1 || day > 31) {
  alert("Please enter the correct day");
} else {
  if ((month === "january" && day > 20) || (month === "february" && day < 19)) {
    alert("You are Aquarius");
  } else if (
    (month === "february" && day > 18) ||
    (month === "march" && day < 19)
  ) {
    alert("You are Pisces - Рыбы");
  } else if (
    (month === "march" && day > 20) ||
    (month === "april" && day < 19)
  ) {
    alert("You are Aries - Овен");
  } else if ((month === "april" && day > 20) || (month === "may" && day < 19)) {
    alert("You are Taurus - Телец");
  } else if ((month === "may" && day > 20) || (month === "june" && day < 20)) {
    alert("You are Gemini - Близнецы");
  } else if ((month === "june" && day > 21) || (month === "july" && day < 21)) {
    alert("You are Cancer - Рак");
  } else if (
    (month === "july" && day > 22) ||
    (month === "august" && day < 22)
  ) {
    alert("You are Leo - Лев");
  } else if (
    (month === "august" && day > 23) ||
    (month === "september" && day < 21)
  ) {
    alert("You are Virgo - Дева");
  } else if (
    (month === "september" && day > 22) ||
    (month === "october" && day < 22)
  ) {
    alert("You are Libra - Весы");
  } else if (
    (month === "october" && day > 23) ||
    (month === "november" && day < 21)
  ) {
    alert("You are Scorpio - Скорпион");
  } else if (
    (month === "november" && day > 22) ||
    (month === "december" && day < 20)
  ) {
    alert("You are Sagittarius - Стрелец");
  } else if (
    (month === "december" && day > 21) ||
    (month === "january" && day < 19)
  ) {
    alert("You are Capricorn - Водолей");
  } else {
    alert("Please enter the correct month");
  }
}
